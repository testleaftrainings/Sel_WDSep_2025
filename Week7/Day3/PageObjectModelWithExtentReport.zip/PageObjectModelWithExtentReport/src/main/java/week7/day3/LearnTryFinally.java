package week7.day3;

public class LearnTryFinally {

	public static void main(String[] args) {
		try {
			int number=7;
		System.out.println(number/0);
		}
		finally {
			System.out.println("Report status");
		}
	}

}
