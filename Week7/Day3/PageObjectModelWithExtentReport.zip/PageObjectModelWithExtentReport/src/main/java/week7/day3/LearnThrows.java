package week7.day3;

public class LearnThrows {

	public static void main(String[] args) throws InterruptedException,ArithmeticException {
		Thread.sleep(0);

	}

}
