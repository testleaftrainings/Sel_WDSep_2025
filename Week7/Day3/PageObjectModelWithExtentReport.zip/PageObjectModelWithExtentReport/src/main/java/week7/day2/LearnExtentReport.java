package week7.day2;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class LearnExtentReport {

	public static void main(String[] args) {
		//Step1: Setup the path
		ExtentHtmlReporter reporter=new ExtentHtmlReporter("./Reports/Leaftaps.html");
		
		//Step2: Create a Test
		ExtentReports extent=new ExtentReports();
		
		//Step3: Adding the test to the html page
		extent.attachReporter(reporter);
		
		//Step4: Create the testcases
		ExtentTest test = extent.createTest("CreateLead", "CreateLead with multiple data");

		//Step5: Assign details to the testcase
		test.assignAuthor("Vineeth");
		test.assignCategory("Regression");
		
		//Step6:Close the report-flush()
		extent.flush();
		
		
		System.out.println("Code completed");
		
		
	}

}
