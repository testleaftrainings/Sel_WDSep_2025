package week7.day3;

public class LearnFinal1 {

	public static void main(String[] args) {
		final int number=10;
		number=number+5;
		System.out.println(number);
	}
	
	
	
}
