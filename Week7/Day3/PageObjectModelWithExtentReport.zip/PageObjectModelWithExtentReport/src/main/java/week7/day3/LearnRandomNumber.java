package week7.day3;

public class LearnRandomNumber {

	public static void main(String[] args) {
		int randomNumber = (int)(Math.random()*9999999+999999);
		System.out.println(randomNumber);

	}

}
//0.7857788864251719             image4554844
//0.4781314494809974             image5422993