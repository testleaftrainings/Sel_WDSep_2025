package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.edge.EdgeDriver;

import base.BaseClass;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class CreateLeadPage extends BaseClass {
	
	
	@Given("Enter the Companyname as (.*)$")
	public CreateLeadPage enterCompanyName(String companyName) {
		getDriver().findElement(By.id("createLeadForm_companyName")).sendKeys(companyName);
        return this;
	}
	@And("Enter the Firstname as (.*)$")
	public CreateLeadPage enterFirstname(String firstName) {
		getDriver().findElement(By.id("createLeadForm_firstName")).sendKeys(firstName);
return this;
	}
	@And("Enter the Lastname as (.*)$")
	public CreateLeadPage enterLastname(String lastName) {
		getDriver().findElement(By.id("createLeadForm_lastName")).sendKeys(lastName);
return this;
	}

	@When("Click on the CreateLead button")
	public ViewPage clickCreateLeadbutton() {
		getDriver().findElement(By.name("submitButton")).click();
      return new ViewPage();
	}



}
