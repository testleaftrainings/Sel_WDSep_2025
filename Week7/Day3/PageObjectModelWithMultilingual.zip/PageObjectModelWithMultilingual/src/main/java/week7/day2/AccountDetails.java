package week7.day2;

public class AccountDetails {
	
	private int accountNumber;
	//                  12345
	public void set(int accountNumber) {
		this.accountNumber=accountNumber;
		
	}
	
	public int get() {
		return accountNumber;   
	}

}
