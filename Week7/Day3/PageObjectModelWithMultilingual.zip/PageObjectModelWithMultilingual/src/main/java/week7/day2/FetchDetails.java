package week7.day2;

public class FetchDetails {
	
	public static void main(String[] args) {
		AccountDetails ac=new AccountDetails();
		ac.set(12345);
		int accNumber = ac.get();
		System.out.println(accNumber);
	}

}
