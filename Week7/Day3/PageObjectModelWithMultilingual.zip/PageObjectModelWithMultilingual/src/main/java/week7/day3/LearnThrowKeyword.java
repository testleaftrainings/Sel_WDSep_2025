package week7.day3;

public class LearnThrowKeyword {

	public static void main(String[] args) {
		int age=-18;
		if(age>=18) {
			System.out.println("Eligible for vote");
		}
		else {
			System.out.println("Not eligible for vote");
		}
		if(age<=0) {
			throw new ArithmeticException("Age is negative");
		}
	}

}
