package week7.day3;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class LearnPropertyFile {

	public static void main(String[] args) throws IOException {
		//Step1
		FileInputStream fis=new FileInputStream("src/main/resources/english.properties");

		//Step2:
		Properties prop=new Properties();
		
		//Step3:
		prop.load(fis);
		
		//To retreive the value
		String valueOfUsername = prop.getProperty("username");
		System.out.println(valueOfUsername);
		
	}

}
