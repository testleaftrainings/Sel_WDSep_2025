package base;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.ReadExcel;

public class BaseClass extends AbstractTestNGCucumberTests {
	
	//public EdgeDriver driver;     //ABCD
	private static final ThreadLocal<EdgeDriver> driver=new ThreadLocal<EdgeDriver>();
	public static ExtentReports extent;
	public static ExtentTest test;
	public String testcaseName,testcaseDescription,testcaseAuthor,testcaseCategory;
	public static Properties prop;
	public  void setDriver() {
		driver.set(new EdgeDriver());
	}
	
	public EdgeDriver getDriver() {
		EdgeDriver driverValue = driver.get();
		return driverValue;
	}
	
	
	public String filename;
	@BeforeMethod
	public void preConditions() throws IOException {
		       //Step1
				FileInputStream fis=new FileInputStream("src/main/resources/french.properties");

				//Step2:
				prop=new Properties();
				
				//Step3:
				prop.load(fis);
		//driver=new EdgeDriver();
		setDriver();
		getDriver().get("http://leaftaps.com/opentaps/control/main");
		getDriver().manage().window().maximize();

	}
	@AfterMethod
	public void postConditions() {
		getDriver().close();

	}
	
	@DataProvider(name="fetchData")
	public String[][] sendData() throws IOException {
		return ReadExcel.readData(filename);    //CreateLead

	}
	@BeforeSuite
	public void startReport() {
		//Step1: Setup the path
				ExtentHtmlReporter reporter=new ExtentHtmlReporter("./Reports/Leaftaps.html");
				
				//Step2: Create a Test
				extent=new ExtentReports();
				
				//Step3: Adding the test to the html page
				extent.attachReporter(reporter);

	}
	@AfterSuite
	public void endReport() {
		extent.flush();

	}
	@BeforeClass
	public void testcaseDetails() {
		test = extent.createTest(testcaseName, testcaseDescription);  
		test.assignAuthor(testcaseAuthor);
		test.assignCategory(testcaseCategory);

	}
	
	
	
	public int takeSnap() throws IOException {
		int randomNumber = (int)(Math.random()*9999999+999999);
		
		File source = getDriver().getScreenshotAs(OutputType.FILE);
		
		File destination=new File("./Snaps/image"+randomNumber+".png");
		
		FileUtils.copyFile(source, destination);
		
		return randomNumber;

	}
	
       public void reportStep(String message, String status) throws IOException {
		
		if(status.equals("Pass")) {
			test.pass(message,MediaEntityBuilder.createScreenCaptureFromPath(".././Snaps/image"+takeSnap()+".png").build());
		}
		

	}

}
