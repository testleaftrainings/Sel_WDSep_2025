package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.edge.EdgeDriver;

import base.BaseClass;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;

public class LoginPage extends BaseClass {
	
	
	@And("Enter the username as {string}")
	public LoginPage enterUsername(String username) throws IOException {
		String propertyOfUsername = prop.getProperty("username");
		getDriver().findElement(By.id("username")).sendKeys(propertyOfUsername);
		reportStep("Username entered successfully", "Pass");
        return this;
	}
	@And("Enter the password as {string}")
	public LoginPage enterPassword(String password) {
		String propertyOfPassword = prop.getProperty("password");
		getDriver().findElement(By.id("password")).sendKeys(propertyOfPassword);
       return this;
	}
	@When("Click on the Login button")
	public WelcomePage clickLoginButton() {
		getDriver().findElement(By.className("decorativeSubmit")).click();
        WelcomePage wp=new WelcomePage();   //ABCD
        return wp;
	}

}
