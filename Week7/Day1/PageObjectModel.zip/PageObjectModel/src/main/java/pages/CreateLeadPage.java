package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.edge.EdgeDriver;

import base.BaseClass;

public class CreateLeadPage extends BaseClass {
	
	public CreateLeadPage(EdgeDriver driver) {
		this.driver=driver;
	}
	
	public CreateLeadPage enterCompanyName() {
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys("TestLeaf");
        return this;
	}
	
	public CreateLeadPage enterFirstname() {
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys("Vineeth");
return this;
	}
	
	public CreateLeadPage enterLastname() {
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys("Rajendran");
return this;
	}

	
	public ViewPage clickCreateLeadbutton() {
		driver.findElement(By.name("submitButton")).click();
      return new ViewPage(driver);
	}



}
