package pages;

import org.openqa.selenium.edge.EdgeDriver;

import base.BaseClass;

public class ViewPage extends BaseClass {
	
	public ViewPage(EdgeDriver driver) {
		this.driver=driver;
	}
	
	public void verifyLead() {
		System.out.println("Lead is Created");

	}

}
