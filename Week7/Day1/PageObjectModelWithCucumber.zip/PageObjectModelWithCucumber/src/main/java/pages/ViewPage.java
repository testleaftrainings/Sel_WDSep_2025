package pages;

import org.openqa.selenium.edge.EdgeDriver;

import base.BaseClass;
import io.cucumber.java.en.Then;

public class ViewPage extends BaseClass {
	
	public ViewPage(EdgeDriver driver) {
		this.driver=driver;
	}
	@Then("Lead should be created")
	public void verifyLead() {
		System.out.println("Lead is Created");

	}

}
