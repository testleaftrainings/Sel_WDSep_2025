package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.edge.EdgeDriver;

import base.BaseClass;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class CreateLeadPage extends BaseClass {
	
	public CreateLeadPage(EdgeDriver driver) {
		this.driver=driver;
	}
	@Given("Enter the Companyname as (.*)$")
	public CreateLeadPage enterCompanyName(String companyName) {
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(companyName);
        return this;
	}
	@And("Enter the Firstname as (.*)$")
	public CreateLeadPage enterFirstname(String firstName) {
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys(firstName);
return this;
	}
	@And("Enter the Lastname as (.*)$")
	public CreateLeadPage enterLastname(String lastName) {
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lastName);
return this;
	}

	@When("Click on the CreateLead button")
	public ViewPage clickCreateLeadbutton() {
		driver.findElement(By.name("submitButton")).click();
      return new ViewPage(driver);
	}



}
