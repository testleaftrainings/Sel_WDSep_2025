package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.edge.EdgeDriver;

import base.BaseClass;
import io.cucumber.java.en.And;

public class WelcomePage extends BaseClass {
	//                            ABCD
	public WelcomePage(EdgeDriver driver) {
		this.driver=driver;
		//         ABCD =ABCD
	}
	@And("Clcik on the Crmsfa link")
	public MyHomePage clickOnCrmsfa() {
		driver.findElement(By.linkText("CRM/SFA")).click();
        return new MyHomePage(driver); //ABCD
	}

}
