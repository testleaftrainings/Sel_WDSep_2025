package week7.day1;

public class LearnConstructor {
	
	
	int number;
	String name;
	
    public LearnConstructor() {
		System.out.println("I am from default constructor");
	}
    //                            7            Vineeth
    public LearnConstructor(int number, String name) {
    	
    	this.number=number;
    	//number  =7;
    	this.name=name;
    	//  name =Vineeth
    	
    	System.out.println("I am from Paramterized constructor");
    }
	
    public static void main(String[] args) {
		LearnConstructor lc=new LearnConstructor(7,"Vineeth");
		System.out.println(lc.number);
		System.out.println(lc.name);
	}
	

}
//Constructor
	//Special method in java
	//No return type
	//Name of Constructor should exactly same as Class name
	//Default constrctor or Non, Parameterized constrctor