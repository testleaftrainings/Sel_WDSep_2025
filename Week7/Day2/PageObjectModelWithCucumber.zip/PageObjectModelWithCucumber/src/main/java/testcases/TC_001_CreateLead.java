package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class TC_001_CreateLead extends BaseClass {
	
	@BeforeTest
	public void setValues() {
		filename="CreateLead";

	}
	
	@Test(dataProvider ="fetchData")
	public void createLead(String username,String password,String companyName, String firstName,String lastName) {
		LoginPage lp=new LoginPage();     //ABCD
		lp.enterUsername(username)
		.enterPassword(password)
		.clickLoginButton()
		.clickOnCrmsfa()
		.clickLeadsLink()
		.clickCreateLeadLink()
		.enterCompanyName(companyName)
		.enterFirstname(firstName)
		.enterLastname(lastName)
		.clickCreateLeadbutton()
		.verifyLead();

	}

}
//        CreateLead
//@Test   @BeforeTest     @BeforeMethod    @AfterMethod   @DataProvider