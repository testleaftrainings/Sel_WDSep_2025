package pages;

import org.openqa.selenium.By;

import base.BaseClass;
import io.cucumber.java.en.And;
import io.cucumber.java.en.But;
import io.cucumber.java.en.Then;

public class WelcomePage extends BaseClass {
	
	@And("Clcik on the Crmsfa link")
	public MyHomePage clickOnCrmsfa() {
		getDriver().findElement(By.linkText("CRM/SFA")).click();
        return new MyHomePage(); //ABCD
	}
	@Then("It should be navigate to the next page")
	public void verifyLogin() {
		System.out.println("Login successful");

	}
	@But("It should error message")
	public void verifyErrorMessage() {
		System.out.println("It throws error message");

	}

}
