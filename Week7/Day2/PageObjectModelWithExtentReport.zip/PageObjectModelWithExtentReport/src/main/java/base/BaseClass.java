package base;

import java.io.IOException;

import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.ReadExcel;

public class BaseClass extends AbstractTestNGCucumberTests {
	
	//public EdgeDriver driver;     //ABCD
	private static final ThreadLocal<EdgeDriver> driver=new ThreadLocal<EdgeDriver>();
	public static ExtentReports extent;
	public String testcaseName,testcaseDescription,testcaseAuthor,testcaseCategory;
	
	public  void setDriver() {
		driver.set(new EdgeDriver());
	}
	
	public EdgeDriver getDriver() {
		EdgeDriver driverValue = driver.get();
		return driverValue;
	}
	
	
	public String filename;
	@BeforeMethod
	public void preConditions() {
		//driver=new EdgeDriver();
		setDriver();
		getDriver().get("http://leaftaps.com/opentaps/control/main");
		getDriver().manage().window().maximize();

	}
	@AfterMethod
	public void postConditions() {
		getDriver().close();

	}
	
	@DataProvider(name="fetchData")
	public String[][] sendData() throws IOException {
		return ReadExcel.readData(filename);    //CreateLead

	}
	@BeforeSuite
	public void startReport() {
		//Step1: Setup the path
				ExtentHtmlReporter reporter=new ExtentHtmlReporter("./Reports/Leaftaps.html");
				
				//Step2: Create a Test
				extent=new ExtentReports();
				
				//Step3: Adding the test to the html page
				extent.attachReporter(reporter);

	}
	@AfterSuite
	public void endResult() {
		extent.flush();

	}
	@BeforeClass
	public void testcaseDetails() {
		ExtentTest test = extent.createTest(testcaseName, testcaseDescription);  
		test.assignAuthor(testcaseAuthor);
		test.assignCategory(testcaseCategory);

	}

}
