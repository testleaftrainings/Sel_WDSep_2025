package steps;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.But;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;



public class LoginStepDefinition extends BaseClass {
	
	
   @And("Enter the username as {string}")
	public void enter_the_username(String username) {
	    driver.findElement(By.id("username")).sendKeys(username);
	}
	
	
@And("Enter the password as {string}")
	public void enter_the_password(String password) {
	   driver.findElement(By.id("password")).sendKeys(password);
	}
	
	

	@When("Click on the Login button")
	public void click_on_the_login_button() {
	    driver.findElement(By.className("decorativeSubmit")).click();
	}

	@Then("It should be navigate to the next page")
	public void it_should_be_navigate_to_the_next_page() {
	   System.out.println("It navigate to the next page");
	}
	
	@But("It should error message")
	public void it_should_error_message() {
	   System.out.println("It throws error message");
	}

}
