package pages;

import base.BaseClass;

public class ViewPage extends BaseClass {
	
	public void verifyLead() {
		System.out.println("Lead is Created");

	}

}
