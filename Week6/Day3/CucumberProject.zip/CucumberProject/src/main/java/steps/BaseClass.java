package steps;

import org.openqa.selenium.edge.EdgeDriver;

public class BaseClass {
	public static EdgeDriver driver;
}
